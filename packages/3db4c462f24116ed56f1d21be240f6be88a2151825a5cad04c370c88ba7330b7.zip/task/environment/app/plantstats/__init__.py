"""Offline manufacturing statistics package."""
