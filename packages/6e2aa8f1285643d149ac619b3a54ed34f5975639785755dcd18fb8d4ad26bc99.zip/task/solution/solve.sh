printf '5\n' > answer.txt
