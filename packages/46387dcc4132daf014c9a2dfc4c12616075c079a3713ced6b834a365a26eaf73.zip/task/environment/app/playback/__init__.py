"""Local playback activity statistics components."""
