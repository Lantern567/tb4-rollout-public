"""Offline device telemetry package."""
