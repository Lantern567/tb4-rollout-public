"""Offline vehicle observation components."""
