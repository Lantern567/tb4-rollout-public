"""Offline playback activity statistics."""
