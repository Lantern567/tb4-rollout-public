"""Offline instrument observation processing."""
