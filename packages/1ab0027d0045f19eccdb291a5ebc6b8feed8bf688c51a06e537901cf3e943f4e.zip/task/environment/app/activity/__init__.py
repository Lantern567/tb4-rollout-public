"""Offline job activity package."""
