"""Offline operational observation components."""
