from app.answer import answer
print(answer())
