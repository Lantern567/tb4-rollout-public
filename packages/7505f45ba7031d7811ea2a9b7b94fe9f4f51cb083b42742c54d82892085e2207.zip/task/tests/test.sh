#!/bin/bash
set -eu
mkdir -p /logs/verifier
chmod 700 /logs/verifier
python3 /tests/check_gate.py
