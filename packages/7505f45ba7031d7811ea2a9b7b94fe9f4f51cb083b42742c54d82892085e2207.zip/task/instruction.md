修复 /app/submission/answer.json，使 value 为 5。
