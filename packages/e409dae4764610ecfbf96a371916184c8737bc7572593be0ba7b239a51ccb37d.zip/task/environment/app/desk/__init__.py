"""Offline service-ticket activity package."""
