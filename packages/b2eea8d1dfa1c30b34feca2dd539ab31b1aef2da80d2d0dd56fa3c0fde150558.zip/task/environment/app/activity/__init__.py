"""Offline job execution activity organizer."""
