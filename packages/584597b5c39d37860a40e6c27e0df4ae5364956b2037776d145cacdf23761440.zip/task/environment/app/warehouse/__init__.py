"""Offline warehouse scan organization package."""
