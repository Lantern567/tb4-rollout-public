"""Offline equipment statistics package."""
