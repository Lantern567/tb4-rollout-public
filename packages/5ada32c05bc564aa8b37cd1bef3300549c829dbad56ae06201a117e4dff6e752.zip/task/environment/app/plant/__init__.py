"""Offline manufacturing run statistics package."""
