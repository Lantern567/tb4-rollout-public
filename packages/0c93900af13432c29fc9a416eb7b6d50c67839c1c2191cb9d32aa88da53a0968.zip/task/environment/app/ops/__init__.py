"""Offline alert observation package."""
