from dataclasses import dataclass
@dataclass
class Value:
 value:int
