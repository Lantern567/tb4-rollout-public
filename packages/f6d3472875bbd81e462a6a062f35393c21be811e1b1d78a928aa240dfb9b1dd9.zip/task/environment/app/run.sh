#!/bin/sh
exec python3 -m business.runner "$@"
