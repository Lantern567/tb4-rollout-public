# Offline device telemetry package.
