"""Offline vehicle observation runs."""
