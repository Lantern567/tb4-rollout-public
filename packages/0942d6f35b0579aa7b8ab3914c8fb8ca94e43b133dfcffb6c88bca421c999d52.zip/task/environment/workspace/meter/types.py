from dataclasses import dataclass


@dataclass(frozen=True)
class Reading:
    device: str
    time: int
    raw: int
    source: str
