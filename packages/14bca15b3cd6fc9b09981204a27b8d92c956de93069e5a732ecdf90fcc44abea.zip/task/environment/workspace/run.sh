#!/bin/sh
exec python3 /workspace/runner.py "$@"
